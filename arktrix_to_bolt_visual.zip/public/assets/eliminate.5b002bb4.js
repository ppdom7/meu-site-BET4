const e="/static/image/recharge/eliminate.png";export{e as _};
