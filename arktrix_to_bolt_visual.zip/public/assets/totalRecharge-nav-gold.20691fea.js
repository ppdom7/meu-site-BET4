const t="/static/image/activity/totalRecharge/totalRecharge-nav-gold.png";export{t as _};
