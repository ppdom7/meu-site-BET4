const t="/static/image/index/bottom-arrow.png";export{t as _};
