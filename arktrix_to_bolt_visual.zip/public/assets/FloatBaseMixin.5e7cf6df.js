const e={props:{show:{type:Boolean,default:!1},pageScrolling:{type:Boolean,default:!1}},data:()=>({isVisible:!1}),mounted(){setTimeout((()=>{this.isVisible=!0}))}};export{e as F};
