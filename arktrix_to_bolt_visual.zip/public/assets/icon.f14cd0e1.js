const s="/assets/icon-923a6bfd.png";export{s as _};
