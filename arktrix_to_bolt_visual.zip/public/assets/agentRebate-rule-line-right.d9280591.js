const e="/static/image//activity/agentRebate/agentRebate-rule-line-left.png",t="/static/image//activity/agentRebate/agentRebate-rule-line-right.png";export{e as _,t as a};
