(function registerCacheServiceWorker() {
    if (typeof window === 'undefined' || !('serviceWorker' in navigator)) {
        return;
    }

    if (window.self !== window.top) {
        return;
    }

    window.addEventListener('load', function () {
        navigator.serviceWorker.register('/cache-service-worker.js', {
            scope: '/',
            updateViaCache: 'none'
        }).then(function (registration) {
            console.log('Cache Service Worker registered:', registration.scope);
        }).catch(function (error) {
            console.warn('Cache Service Worker registration failed:', error);
        });
    });
})();
