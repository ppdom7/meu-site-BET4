// API replay Service Worker — auto-generated. Do not edit manually.
const MANIFEST = {"POST https://g.adbet77.com/user/v1/checkLogin":"/api-data/2a1b004763996f47.json","GET https://g.adbet77.com/game/v1/timestamp?_t=1790383242349":"/api-data/6d59098eecde43ff.json","GET https://g.adbet77.com/ws/auth?_t=1790383242363":"/api-data/9e04a5af2e48ec9b.json","GET https://g.adbet77.com/game/v1/index?_t=1790383242366":"/api-data/e52ef1c8a0f60335.json","POST https://g.adbet77.com/activity/v1/getPopupsForActivityInfo":"/api-data/ffe86d9393357efa.json","GET https://g.adbet77.com/activity/registerBonus/v1/getActivityData?_t=1790383244708":"/api-data/9378e5a1596c39a6.json"};
const PATH_INDEX = {"POST /user/v1/checkLogin":"/api-data/2a1b004763996f47.json","GET /game/v1/timestamp?_t=1790383242349":"/api-data/6d59098eecde43ff.json","GET /ws/auth?_t=1790383242363":"/api-data/9e04a5af2e48ec9b.json","GET /game/v1/index?_t=1790383242366":"/api-data/e52ef1c8a0f60335.json","POST /activity/v1/getPopupsForActivityInfo":"/api-data/ffe86d9393357efa.json","GET /activity/registerBonus/v1/getActivityData?_t=1790383244708":"/api-data/9378e5a1596c39a6.json"};
const PATH_NO_QUERY_INDEX = {"POST /user/v1/checkLogin":"/api-data/2a1b004763996f47.json","GET /game/v1/timestamp":"/api-data/6d59098eecde43ff.json","GET /ws/auth":"/api-data/9e04a5af2e48ec9b.json","GET /game/v1/index":"/api-data/e52ef1c8a0f60335.json","POST /activity/v1/getPopupsForActivityInfo":"/api-data/ffe86d9393357efa.json","GET /activity/registerBonus/v1/getActivityData":"/api-data/9378e5a1596c39a6.json"};
const ORIGIN_HOSTS = [];

self.addEventListener('install', function(){ self.skipWaiting(); });
self.addEventListener('activate', function(e){ e.waitUntil(self.clients.claim()); });

self.addEventListener('fetch', function(event) {
  var req = event.request;
  var localPath = MANIFEST[req.method + ' ' + req.url];
  if (!localPath) {
    try {
      var u = new URL(req.url);
      // Try by origin+pathname (ignore query)
      localPath = MANIFEST[req.method + ' ' + u.origin + u.pathname];
      // Try by pathname+search (ignore host — main fix for proxy hosting)
      if (!localPath) localPath = PATH_INDEX[req.method + ' ' + u.pathname + u.search];
      // Try by pathname only (ignore query too)
      if (!localPath) localPath = PATH_NO_QUERY_INDEX[req.method + ' ' + u.pathname];
    } catch (e) {}
  }
  if (!localPath) {
    try {
      var mu = new URL(req.url);
      // RE-HOMING de asset (paridade com o proxy): o location-spoof faz o runtime
      // resolver chunks/dados contra a origem ORIGINAL (host-lock defeat), então
      // requests GET vão pro host capturado em vez do host do ZIP. O ZIP tem o
      // arquivo no MESMO pathname → busca local primeiro; miss → cai pra rede.
      // É o que o serve-offer faz servindo por pathname independente do host.
      if (req.method === 'GET' && ORIGIN_HOSTS.indexOf(mu.host) !== -1 && mu.origin !== self.location.origin) {
        var localUrl = self.location.origin + mu.pathname + mu.search;
        event.respondWith(
          fetch(localUrl, { cache: 'no-cache' })
            .then(function(r) { return (r && r.ok) ? r : fetch(req); })
            .catch(function() { return new Response('{"ok":false,"offline":true}', {status:503,headers:{'Content-Type':'application/json'}}); })
        );
        return;
      }
      // Mutação same-origin (POST/PUT/PATCH/DELETE) num host estático bateria num
      // backend inexistente = CORS/404 e o funil TRAVA. Sucesso sintético mantém o
      // funil andando (o cliente reaponta a captura pro próprio gateway/CRM). GET e
      // mutação CROSS-origin (gateway/pixel real do cliente) passam pra rede.
      var isMutation = req.method !== 'GET' && req.method !== 'HEAD' && req.method !== 'OPTIONS';
      if (isMutation && mu.origin === self.location.origin) {
        event.respondWith(new Response('{"ok":true}', {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        }));
        return;
      }
    } catch (e) {}
    return; // fall-through to network
  }
  event.respondWith(
    fetch(localPath, { cache: 'no-cache' })
      .then(function(r) {
        return r.arrayBuffer().then(function(buf) {
          return new Response(buf, {
            status: 200,
            headers: { 'Content-Type': 'application/json', 'X-Replay': '1' }
          });
        });
      })
      .catch(function() { return new Response('{"ok":false,"offline":true}', {status:503,headers:{'Content-Type':'application/json'}}); })
  );
});
