# Arktrix → Bolt import

This folder is a Bolt-ready visual import of the Arktrix capture.

## Important

- The original ZIP was not a normal source project. It was a captured production build with minified JavaScript, mirrored assets, API replay files, and an outer iframe shell.
- This version starts directly from the captured front-end instead of the iframe shell.
- Captured authentication/session token values were removed.
- Live API, websocket, game-launch, payment/auth functionality is intentionally not connected. Reconnect only to services you control and are authorized to use.
- The app is still largely production/minified code. The best next step inside Bolt is to refactor/rebuild the UI into normal React/Vite components while preserving the appearance.

## Run

```bash
npm install
npm run dev
```

## Recommended first prompt in Bolt

Analyze this imported project. Preserve the current visual appearance, spacing, typography, mobile layout, images, navigation, modals, and overall UX, but rebuild the front-end into clean React + TypeScript + Vite components. Do not connect to the old external authentication, payment, casino/game, websocket, tracking, or API endpoints. Replace those integrations with clearly named local mock services/placeholders. Keep all existing visual assets available locally where possible. First make the home page pixel-close to the imported preview, then refactor shared header, navigation, cards, banners, modals, and bottom navigation into reusable components. Do not delete the imported snapshot until the rebuilt React version matches it visually.
